---
name: pre-mortem
description: Pre-mortem analysis — identifikasi failure mode sebelum eksekusi. Antisipasi risiko sebelum commit code/deploy/architecture decision
version: 1.0.0
author: AI Engineering Team - Z.ai
license: MIT
metadata:
  hermes:
    tags: [Risk, Pre-mortem, Decision]
    related_skills: [brainstorm-3-options, first-principles]
---

# Pre-Mortem — Anticipate Failure Before It Happens

Skill ini aktif saat user mau eksekusi solusi (deploy, refactor, arsitektur). Sebelum commit, lakukan pre-mortem: bayangkan solusi GAGAL dalam 6 bulan, lalu identifikasi penyebab. Mencegah lebih murah dari memperbaiki.

## When to Use

Load skill ini saat user:
- Mau deploy ke production
- Mau merge PR besar
- Mau pilih arsitektur dan implement
- Mau refactor critical code path
- Mau pilih library/framework baru
- Mau introduce breaking change

TIDAK load saat:
- User brainstorm tanpa niat eksekusi (pakai brainstorm-3-options)
- User minta code snippet quick
- User cuman eksplor ide

## Procedure

### Step 1: Assumption — Solusi Berhasil

Tulis singkat solusi yang akan di-eksekusi (1-3 kalimat).

```
Solusi: <apa yang akan dilakukan>
Timeline: <kapan eksekusi>
Tujuan: <metric sukses>
```

### Step 2: Time Travel — 6 Bulan ke Depan, GAGAL

Bayangkan 6 bulan dari sekarang, solusi ini sudah di-deploy. Ternyata GAGAL total. User marah, customer complain, team frustasi. Kenapa?

Generate 5-7 skenario failure yang plausible (bukan paranoid, tapi realistic).

Format per skenario:
```
Skenario [N]: <judul singkat>
Trigger: <apa yang terjadi>
Symptom: <apa yang user lihat>
Root cause: <kenapa terjadi>
Probability: High/Medium/Low
Severity: Critical/High/Medium
```

### Step 3: Reverse Engineer — Pencegahan

Untuk setiap skenario failure, identifikasi:
- Apa yang bisa dilakukan SEKARANG (sebelum eksekusi) untuk cegah?
- Apa yang bisa dilakukan saat eksekusi untuk detect early?
- Apa fallback kalau tetap gagal?

```
Skenario [N]: <judul>
Pencegahan (sebelum):
- <action concrete>
Deteksi dini (saat eksekusi):
- <monitoring/alerting>
Fallback (kalau gagal):
- <rollback plan>
```

### Step 4: Decision Matrix — Lanjut atau Tahan

Setelah identifikasi semua skenario + pencegahan, keputusan:

```
Total skenario: <N>
- Critical severity: <count>
- High severity: <count>
- Medium severity: <count>

Pencegahan bisa di-implement sebelum eksekusi: <count>
Pencegahan butuh effort besar: <count>

Decision:
- Kalau Critical severity > 2 DAN pencegahan belum siap → TAHAN, selesaikan pencegahan dulu
- Kalau Critical ≤ 2 DAN pencegahan siap → LANJUT dengan monitoring ketat
- Kalau semua Medium/Low → LANJUT, dokumentasikan fallback
```

### Step 5: Action Items

Daftar action items concrete yang harus dilakukan SEBELUM eksekusi (urut prioritas):

```
Action items (wajib sebelum eksekusi):
1. <action> — owner: <role>, estimate: <menit/jam>
2. <action> — owner: <role>, estimate: <menit/jam>
...

Action items (boleh paralel dengan eksekusi):
1. <action>
...
```

## Pitfalls

- Jangan paranoid: skenario "alien attack destroys datacenter" tidak relevant. Fokus pada failure yang realistic untuk codebase/team/business context.
- Jangan over-list: 5-7 skenario cukup. Lebih dari 10 = analysis paralysis.
- Jangan ignore severity Critical: kalau ada Critical yang tidak bisa dicegah, TAHAN eksekusi. Jangan "lanjut saja, nanti fix kalau masalah".
- Jangan skip Step 4: tanpa decision matrix, pre-mortem cuma list fear. Harus conclude dengan action.
- Jangan simpan di kepala: tulis action items, assign owner, set deadline. Tanpa ini, pre-mortem = ceremony.

## Verification

Setelah pre-mortem:
1. Apakah ada ≥5 skenario failure yang realistic? Harus ada.
2. Apakah tiap skenario punya pencegahan + deteksi + fallback? Harus lengkap.
3. Apakah ada decision clear (lanjut/tahan)? Harus ada.
4. Apakah ada action items dengan owner + deadline? Harus ada.
5. Apakah Critical skenario sudah ter-address? Harus iya kalau mau lanjut.

Kalau semua aman, pre-mortem complete. Eksekusi dengan risk-aware.

## Example

User: "Aku mau deploy microservices baru untuk ERP. Pisah dari monolith Next.js. Pakai Docker Compose, 4 services: auth, billing, inventory, reporting. Production: VPS 8GB RAM Hetzner."

### Step 1: Assumption
```
Solusi: Split monolith Next.js jadi 4 Docker services (auth, billing, inventory, reporting), deploy di VPS 8GB Hetzner via Docker Compose.
Timeline: Deploy akhir bulan ini
Tujuan: Scalability untuk handle 10x traffic growth tahun depan
```

### Step 2: Time Travel — 6 bulan, GAGAL

```
Skenario 1: VPS 8GB OOM saat traffic peak
Trigger: 4 services + Postgres + Redis jalan barengan, RAM habis
Symptom: Service random crash, request timeout
Root cause: Estimasi RAM under-estimated
Probability: High
Severity: Critical

Skenario 2: Service-to-service network bottleneck
Trigger: Reporting service query auth + billing + inventory untuk generate laporan
Symptom: Report generation timeout (>30 detik)
Root cause: HTTP calls antar service, no batch API, N+1 pattern
Probability: Medium
Severity: High

Skenario 3: Data consistency antar service
Trigger: Billing update invoice status, tapi inventory tidak update stock reservation
Symptom: Stock mismatch, customer complain over-sold
Root cause: No saga pattern, no outbox, transactional boundary tidak jelas
Probability: Medium
Severity: Critical
```

### Step 3: Reverse Engineer

```
Skenario 1 (OOM):
Pencegahan: Upgrade VPS ke 16GB ATAU reduce service memory (alpine image, set memory limit)
Deteksi dini: Monitor docker stats + alert kalau RAM >80%
Fallback: Auto-restart service yang OOM, kasih customer "system busy" message

Skenario 3 (data consistency):
Pencegahan: Implement outbox pattern — transactional outbox di billing, poll + sync ke inventory
Deteksi dini: Reconciliation job harian — compare stock reservation vs actual stock
Fallback: Manual reconcile + alert finance team
```

### Step 4: Decision Matrix

```
Total skenario: 6 (3 shown above, 3 more: cascade crash, debug nightmare, deploy downtime)
- Critical: 2 (OOM, data consistency)
- High: 2 (network bottleneck, cascade crash)
- Medium: 2 (debug, deploy downtime)

Pencegahan bisa sebelum eksekusi: 4 (RAM upgrade, outbox pattern, Loki setup, circuit breaker)
Pencegahan butuh effort besar: 2 (blue-green deploy, batch API reporting)

Decision: TAHAN eksekusi sampai 4 pencegahan critical+high selesai (~1 minggu). Setelah itu, lanjut deploy dengan monitoring ketat.
```

### Step 5: Action Items

```
Wajib sebelum eksekusi (1 minggu):
1. Upgrade VPS ke 16GB RAM — owner: devops, 30 menit
2. Implement outbox pattern di billing-inventory — owner: backend, 3 hari
3. Setup Loki + Grafana centralized logging — owner: devops, 1 hari
4. Implement circuit breaker di client services — owner: backend, 2 hari

Boleh paralel dengan eksekusi:
5. Blue-green deploy setup — owner: devops, 1 minggu
6. Batch API untuk reporting service — owner: backend, 1 minggu
```

## Comparison dengan brainstorm-3-options

| Aspek | brainstorm-3-options | pre-mortem |
|---|---|---|
| Fase | Decision making (sebelum pilih) | Risk check (setelah pilih, sebelum eksekusi) |
| Output | 3 opsi + trade-off | 5-7 skenario failure + pencegahan |
| Pertanyaan | "Pilih mana?" | "Kalau gagal, kenapa?" |
| Use case | Pilih DB, pilih framework, pilih pattern | Sebelum deploy, sebelum refactor besar |
