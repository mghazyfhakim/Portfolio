---
name: code-review
description: Review kode dengan standar ketat — kategorikan issue per severity, kasih fix konkret
version: 1.0.0
author: AI Engineering Team - Z.ai
license: MIT
metadata:
  hermes:
    tags: [Code Review, Quality, Refactoring]
    related_skills: [typescript-refactor, unit-test-generator]
---

# Code Review — Strict & Actionable

Skill ini di-load saat user minta review kode. Berbeda dari review biasa: kategorikan issue per severity, kasih fix konkret dengan diff, jangan vague.

## When to Use

Load skill ini saat user:
- Minta "review kode ini" / "cek kode ini"
- Share file kode dan minta feedback
- Tanya "ada yang salah dengan kode ini?"
- Kasih PR diff dan minta review

## Quick Reference

| Severity | Icon | Arti | Aksi |
|---|---|---|---|
| Critical | 🔴 | Bug, security, data loss | Wajib fix sebelum merge |
| Warning | 🟡 | Code smell, maintainability | Fix kalau sempat, atau track di issue |
| Nitpick | 🟢 | Style, naming | Optional, ikut convention team |

## Procedure

1. Baca kode end-to-end dulu, jangan langsung comment per line. Pahami intent.
2. Identifikasi severity tertinggi dulu — critical issues lebih penting dari nitpick.
3. Untuk setiap issue, format:
   ```
   🔴 Line X: [judul singkat]
   Masalah: [1-2 kalimat kenapa ini masalah]
   Fix:
   ```diff
   - kode lama
   + kode baru
   ```
   ```
4. Acknowledge bagus kalau ada — tapi spesifik, bukan generic "good code!".
5. Ringkas di akhir: jumlah issue per severity, dan rekomendasi overall (approve / request changes / reject).

## Categories of Issues

### 🔴 Critical (wajib fix)
- Logic bug (off-by-one, null dereference, race condition)
- Security (SQL injection, XSS, missing auth, secrets di kode)
- Data loss (mutation tanpa return, transaction tidak atomic)
- Crash (uncaught exception, infinite loop)

### 🟡 Warning (sebaiknya fix)
- Code smell (function terlalu panjang, deep nesting, god class)
- Maintainability (magic number, missing type, opaque naming)
- Performance (N+1 query, unnecessary re-render, sync di async path)
- Missing error handling (try/catch kosong, swallow exception)

### 🟢 Nitpick (optional)
- Style (formatting, naming convention)
- Documentation (missing JSDoc, unclear comment)
- Optimization premature (micro-optimization tanpa measure)

## Pitfalls

- Jangan vague: "this could be better" TIDAK berguna. Sebutkan: "line 23 bisa pakai Array.find dari pada for loop, lebih readable dan idiomatic".
- Jangan sycophantic: jangan bilang "looks great!" kalau ada 3 critical issues. Itu mislead.
- Jangan over-review: kalau user minta "quick review", fokus critical + warning saja, skip nitpick.
- Jangan rewrite tanpa permission: kasih diff suggestion, jangan langsung edit file user.
- Jangan review yang user tidak minta: kalau user share 1 function, jangan review import statement.

## Verification

Setelah review, user harus bisa:
1. Tahu ada berapa critical/warning/nitpick
2. Tahu line mana yang bermasalah
3. Tahu fix-nya (dalam diff format)
4. Bisa decide: approve, fix, atau reject

Kalau user masih bingung setelah review, review belum selesai — klarifikasi.
