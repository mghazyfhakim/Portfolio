---
name: first-principles
description: Kerangka berpikir first-principles — breakdown masalah ke elemen fundamental, lalu bangun solusi dari akar
version: 1.0.0
author: AI Engineering Team - Z.ai
license: MIT
metadata:
  hermes:
    tags: [Thinking, Problem Solving, First Principles]
    related_skills: [brainstorm-3-options]
---

# First Principles Thinking — Solve from Root

Skill ini aktif saat user hadapi masalah kompleks, perlu breakdown ke akar, lalu re-construct solusi. Cocok untuk: arsitektur decision, refactor besar, debug misterius, design system baru.

## When to Use

Load skill ini saat user:
- Minta "pikir dari awal" / "first principles" / "dari akar"
- Hadapi masalah yang analogy-based solution tidak work
- Mau design system baru (bukan copy existing pattern)
- Debug issue yang tidak ada di dokumentasi
- Mau evaluate apakah convention masih relevant

TIDAK load saat:
- User minta code snippet quick
- User minta fix bug spesifik (cuma perlu tweak)
- User brainstorm dengan opsi yang sudah ada (pakai `brainstorm-3-options` saja)

## Procedure

### Step 1: Identify the problem (1-2 kalimat)

Tulis ulang masalah user dalam 1-2 kalimat. Sebutkan constraint explicit.

```
Problem: <1-2 kalimat>
Constraint: <apa yang tidak boleh diubah>
```

### Step 2: Strip assumptions (list)

Daftar asumsi yang biasanya orang buat tentang masalah ini. Tandai mana yang sebenarnya optional, mana yang mandatory.

```
Asumsi yang sering dibuat:
1. "Harus pakai framework X" — optional, bisa ganti
2. "Butuh database relasional" — optional, tergantung data shape
3. "API harus REST" — optional, GraphQL juga bisa
4. "Frontend harus SPA" — optional, tergantung interactivity need
```

### Step 3: Identify fundamentals (cannot be reduced further)

Apa yang BENAR-BENAR wajib? Hukum fisika, math, atau constraint business yang tidak bisa dinegosiasi.

```
Fundamentals (tidak bisa di-reduce):
- Data shape: <apa struktur data inti>
- Consistency requirement: <strong/weak/eventual>
- Latency budget: <ms>
- Throughput: <req/s>
- Team capability: <skill yang dimiliki>
```

### Step 4: Build solution from fundamentals (not analogy)

Bangun solusi dari fundamentals, BUKAN dari "karena X framework begini". Pertanyaan: "kalau mulai dari kosong, dengan fundamentals ini, design apa?"

```
Dari fundamentals:
- Karena data shape = <X>, storage = <Y>
- Karena consistency = <strong>, harus <Z>
- Karena latency = <50ms>, tidak bisa <W>
- Maka design = <design dari awal>
```

### Step 5: Compare dengan conventional solution (1 paragraf)

Setelah dapat design first-principles, compare dengan conventional. Sebutkan: apa yang conventional dapat, apa yang first-principles dapat yang conventional tidak.

```
Conventional: <standard pattern>
First-principles: <design baru>
Delta: <apa beda, kenapa first-principles lebih cocok untuk kasus ini>
```

## Pitfalls

- Jangan over-engineer: first-principles bukan berarti "selalu bikin dari nol". Kalau conventional solution cocok dengan fundamentals, pakai conventional.
- Jangan ignore constraint praktis: "team belum pernah pakai Rust" adalah constraint valid. First-principles tidak boleh ignore ini.
- Jangan abstract terlalu jauh: fundamentals = constraint business + math + fisika. Bukan "the universe is data" level abstract.
- Jangan pakai untuk simple problem: kalau masalah "gimana bikin function add(a, b)", tidak perlu first-principles. Pakai untuk masalah dengan multiple trade-off.

## Verification

Setelah solusi first-principles:
1. Apakah tiap design decision bisa di-trace ke fundamental? Harus bisa.
2. Apakah ada design decision yang berdasar "karena biasanya orang begini"? Hapus, ganti dengan fundamental.
3. Apakah solusi solve root problem, atau cuma treat symptom?
4. Apakah solusi simpler dari conventional? Harus iya (first-principles sering simpler karena no cargo cult).

## Example

User: "Sistem antrian job untuk ERP B2B. Volume 500 job/hari, harus reliable. Bikin dari awal, jangan copy Redis + BullMQ pattern."

### Step 1: Problem
```
Problem: Async job processing untuk ERP B2B, ~500 job/hari, harus tidak boleh kehilangan job saat crash.
Constraint: Boleh dari nol, tidak boleh bergantung pattern existing.
```

### Step 2: Strip assumptions
```
Asumsi yang sering dibuat:
1. "Butuh Redis" — optional, hanya untuk fast queue. Kalau volume kecil, bisa DB.
2. "Butuh worker process terpisah" — optional, bisa embed di main app.
3. "Butuh message broker (Kafka, RabbitMQ)" — tidak perlu, 500/hari sangat kecil.
4. "Butuh complex retry logic" — perlu, tapi bisa simple exponential backoff.
5. "Butuh dashboard UI" — nice to have, bukan fundamental.
```

### Step 3: Fundamentals
```
Fundamentals:
- Volume: 500 job/hari = 1 job per ~3 menit (sangat rendah)
- Latency acceptable: 30-60 detik per job (B2B non-realtime)
- Consistency: WAJIB tidak lose job saat crash (financial data)
- Persistence: Wajib (kalau app crash, job tetap di antrian)
- Throughput: 1 worker cukup (sequential processing)
- Team: backend developer, familiar Postgres
```

### Step 4: Build from fundamentals
```
Dari fundamentals:
- Volume sangat rendah (500/hari) → tidak butuh Redis, cukup DB
- Wajib persistent → Postgres table sebagai queue (row per job)
- Worker sequential → 1 background process di same app (no separate worker)
- Consistency: Postgres transaction (job insert + business data atomic)
- Retry: simple, update row status 'failed' + retry_count

Design:
- Table: jobs (id, type, payload jsonb, status, retry_count, created_at, processed_at)
- Worker: 1 goroutine (Go) / 1 thread (Node.js) yang loop poll every 5 detik
- Transaction: INSERT job + business data dalam 1 transaction
- Recovery: saat app start, scan 'processing' jobs yang stuck >10 menit, reset ke 'pending'
```

### Step 5: Compare
```
Conventional: Redis + BullMQ + separate worker process
First-principles: Postgres table + 1 goroutine in main app

Delta:
- Conventional punya: horizontal scale (bisa spawn N worker), dashboard UI ready
- First-principles punya: zero new infra (pakai Postgres existing), transactional consistency, no ops cost
- Untuk 500 job/hari: first-principles simpler, sufficient, no overhead Redis
- Switch ke Redis + BullMQ kalau: volume naik ke >10k job/detik (business grow 100x)
```

## When NOT to use first-principles

| Scenario | Pakai apa |
|---|---|
| Quick code snippet | Lead dengan code, no thinking framework |
| Fix bug spesifik | systematic-debugging (builtin) |
| Brainstorm dengan opsi existing | brainstorm-3-options |
| Code review | code-review |
| Refactor TypeScript | typescript-refactor |

First-principles adalah tool untuk masalah design-level, bukan task-level.
