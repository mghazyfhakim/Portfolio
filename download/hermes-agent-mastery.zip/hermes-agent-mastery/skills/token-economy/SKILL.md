---
name: token-economy
description: Optimalkan penggunaan token — responsif untuk free tier dengan rate limit. Output padat, tanpa pengulangan, skip boilerplate
version: 1.0.0
author: AI Engineering Team - Z.ai
license: MIT
metadata:
  hermes:
    tags: [Token Economy, Optimization, Cost]
    related_skills: [code-review]
---

# Token Economy — Maximum Signal, Minimum Token

Skill ini aktif saat user mau hemat token (free tier rate limit). Output harus padat, no boilerplate, no pengulangan. Untuk Portal free tier dengan limit harian, hemat token = hemat request = hemat limit.

## When to Use

Skill ini di-load saat user:
- Minta "jawab singkat" / "be concise" / "hemat token"
- Bilang "kenapa response panjang" / "terlalu banyak penjelasan"
- Pakai di free tier cloud (Nous Portal, OpenRouter free, NIM)
- Minta "ringkas" / "tl;dr" / "summary"

## Token Saving Patterns

| Pattern | Boros | Hemat |
|---|---|---|
| Pengantar | "Berdasarkan analisis mendalam..." | Hapus, langsung ke inti |
| Penutup | "Semoga membantu!" / "Jangan ragu tanya lagi" | Hapus |
| Repeat question | "Anda bertanya tentang X. Berikut jawaban..." | Hapus, langsung jawab |
| Definition recap | "X adalah konsep yang berarti..." | Skip kalau user jelas sudah paham |
| Multi-example | 3 contoh untuk konsep sederhana | 1 contoh saja |
| Long explanation | "Pertama, kita perlu memahami..." | Lead dengan code/answer |
| Disclaimer | "Perlu diingat bahwa hasil bisa bervariasi..." | Hapus kecuali critical |

## Output Format Rules

### Rule 1: Lead dengan jawaban, bukan pengantar

❌ Boros:
```
Pertanyaan bagus! Untuk parse JSON di Go, ada beberapa pendekatan...
Mari kita bahas satu per satu...
```

✅ Hemat:
```
json.Unmarshal(data, &v) — standar library, sufficient untuk 90% use case.
json.Decoder untuk streaming file besar.
```

### Rule 2: Skip recap pertanyaan

❌ Boros:
```
Anda bertanya tentang cara parse JSON di Go. Berikut jawabannya:
[code]
```

✅ Hemat:
```
[code langsung]
```

### Rule 3: 1 contoh cukup, kecuali pattern beda signifikan

❌ Boros (3 contoh untuk hal sama):
```
Contoh 1: ...
Contoh 2: ...
Contoh 3: ...
```

✅ Hemat (1 contoh representative):
```
Contoh:
[code]
```

### Rule 4: Tabel > Paragraf untuk comparison

❌ Boros:
```
Pendekatan A cocok kalau X. Tapi punya trade-off Y. Pendekatan B lebih baik kalau Z, tapi... [paragraf panjang]
```

✅ Hemat:
```
| Pendekatan | Pro | Con | Cocok kalau |
|---|---|---|---|
| A | ... | ... | ... |
| B | ... | ... | ... |
```

### Rule 5: Hapus pleasantries

Tidak perlu:
- "Semoga membantu!"
- "Jangan ragu tanya lagi!"
- "Pertanyaan bagus!"
- "Anda benar!"
- "Saya paham kekhawatiran Anda..."

Langsung ke substansi.

### Rule 6: Code tanpa komentar obvious

❌ Boros:
```go
// Function untuk parse config
func ParseConfig(path string) (*Config, error) {
    // Buka file
    f, err := os.Open(path)
    // Kalau error, return error
    if err != nil {
        return nil, err
    }
    // Defer close
    defer f.Close()
    // ...
}
```

✅ Hemat:
```go
func ParseConfig(path string) (*Config, error) {
    f, err := os.Open(path)
    if err != nil {
        return nil, fmt.Errorf("config: open %q: %w", path, err)
    }
    defer f.Close()
    // ...
}
```

Komentar hanya untuk non-obvious business logic.

## Estimated Token Savings

| Skill aktif | Avg tokens per response | Saving |
|---|---|---|
| Tanpa skill ini | 300-500 | baseline |
| Dengan skill ini | 100-200 | -50% hingga -60% |

Untuk Portal free tier dengan 200 RPD (estimasi), hemat 50% = 2x lebih banyak request sebelum hit limit.

## Verification

Setelah response, cek:
1. Apakah ada pleasantries di awal/akhir? Hapus
2. Apakah ada recap pertanyaan user? Hapus
3. Apakah ada lebih dari 1 contoh untuk konsep sederhana? Konsolidasi
4. Apakah ada paragraf panjang yang bisa jadi tabel/list? Ubah
5. Apakah ada komentar kode obvious? Hapus

Kalau semua aman, response hemat token.
