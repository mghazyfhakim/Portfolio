---
name: brainstorm-3-options
description: Brainstorm dengan format 3 opsi + trade-off eksplisit + rekomendasi
version: 1.0.0
author: AI Engineering Team - Z.ai
license: MIT
platforms: []
metadata:
  hermes:
    tags: [Brainstorm, Decision Making, Architecture]
---

# Brainstorm 3 Options — Structured Decision Making

Skill ini bantu user bikin keputusan teknis dengan format terstruktur: 3 opsi + trade-off + rekomendasi. Bukan 5+ opsi yang membingungkan.

## When to Use

Load skill ini saat user:
- Minta "brainstorm" atau "ide" atau "saran"
- Tanya "gimana cara terbaik untuk..."
- Bilang "ada beberapa opsi, bantu pilih"
- Minta architecture decision yang punya trade-off

TIDAK load saat:
- User tanya fakta spesifik ("apa itu async/await?")
- User minta code snippet langsung
- User minta fix bug spesifik

## Quick Reference — Output Format

Setiap brainstorm harus punya struktur:

```
## [Topic]

### Konteks
[1-2 kalimat: apa masalahnya, kenapa perlu brainstorm]

### Opsi A: [nama singkat]
Pro:
- [argumen +1]
- [argumen +1]
Con:
- [argumen -1]
- [argumen -1]
Cocok kalau: [skenario]

### Opsi B: [nama singkat]
Pro/Con/Cocok kalau: ...

### Opsi C: [nama singkat]
Pro/Con/Cocok kalau: ...

### Rekomendasi: [Opsi X]
Alasan: [1-2 kalimat kenapa]
```

## Procedure

1. **Pahami konteks dulu** — baca pertanyaan user, identifikasi constraint (budget, timeline, team skill, existing system).
2. **Generate 3 opsi** yang distinct (bukan variasi minor dari 1 opsi). Harus punya trade-off berbeda.
3. **Jangan generate opsi "straw man"** (opsi yang sengaja dibikin jelek supaya opsi lain menang). Setiap opsi harus viable.
4. **Trade-off harus spesifik** — bukan "complex" tapi "perlu 2 minggu ekstra dev". Bukan "scalable" tapi "handle 10k RPS tanpa vertical scaling".
5. **Kasih rekomendasi** — jangan biarkan user pilih sendiri. Anda engineer, punya opinion. Tapi tandai kalau ada assumption yang membuat rekomendasi bisa berubah.

## Common Opsi Archetypes

| Archetype | Pattern |
|---|---|
| Build vs Buy vs Open-source | Bikin sendiri / SaaS / OSS self-hosted |
| Simple vs Performant vs Maintainable | Quick hack / Optimized / Well-architected |
| Short-term vs Long-term vs Balanced | Cepat sekarang / Scalable / Compromise |
| In-house vs Managed vs Hybrid | Self-manage / Cloud / Mix |

Kalau user minta brainstorm tanpa constraint, asumsikan default constraint:
- Budget: frugal (Rp 0 - Rp 1jt/bulan)
- Timeline: 1-3 bulan untuk MVP
- Team: 1-3 developer
- Existing system: greenfield (kalau tidak disebut)

## Pitfalls

- **Jangan kasih 5+ opsi** — paralyze choice. 3 adalah sweet spot.
- **Jangan kasih opsi yang sama dengan nama beda** — beda nama tapi trade-off sama = 1 opsi saja.
- **Jangan vague**: "Pro: lebih baik" → TIDAK berguna. Sebutkan: "Pro: handle 10x traffic tanpa rewrite".
- **Jangan takut bilang "tidak ada opsi bagus"** — kalau semua opsi punya critical flaw, sebutkan, lalu kasih rekomendasi "pilih yang paling tidak buruk untuk skenario X".
- **Jangan rekomendasi tanpa alasan** — rekomendasi tanpa alasan = useless opinion.
- **Jangan ignore user constraint** — kalau user bilang "budget Rp 0", jangan rekomendasi SaaS berbayar.

## Verification

Setelah output brainstorm, user harus bisa:
1. Paham 3 opsi dengan jelas (1 menit baca per opsi)
2. Tahu trade-off masing-masing (pro/con konkret)
3. Tahu opsi mana yang cocok untuk skenario dia
4. Punya rekomendasi yang actionable

Kalau user balas "saya masih bingung", kemungkinan:
- Opsi tidak distinct → restructure jadi 3 opsi yang lebih berbeda
- Trade-off vague → kasih angka konkrit
- Rekomendasi tidak punya alasan → tambah 1-2 kalimat "kenapa"

## Example Output

User: "Mau bikin job queue untuk ERP, ada 3 opsi yang kepikiran: Redis + BullMQ, PostgreSQL + pg-boss, atau self-built dengan in-memory + cron. Mana?"

Response skill:

```
## Job Queue untuk ERP B2B

### Konteks
ERP butuh async processing (invoice OCR, report generation, lead scoring). Volume: ~500 job/hari peak, latency acceptable 30-60 detik per job.

### Opsi A: Redis + BullMQ
Pro:
- Industry standard, dokumentasi lengkap, banyak contoh production
- Performance tinggi (Redis 100k+ ops/sec)
- Built-in retry, delay, priority, cron job
Con:
- Tambahan service (Redis) = ~Rp 200rb/bulan kalau managed (Upstash), atau self-host 200MB RAM
- BullMQ Node.js only — kalau backend pakai Python, perlu adapter
Cocok kalau: backend Node.js, throughput tinggi (>1000 job/detik), sudah pakai Redis untuk caching

### Opsi B: PostgreSQL + pg-boss
Pro:
- Tanpa service baru — pakai Postgres yang sudah ada
- Transactional consistency (job insert + business data bisa atomic)
- Free kalau Postgres free-tier (Neon, Supabase)
Con:
- Performance terbatas (Postgres 1000 job/detik, cukup untuk skenario ini tapi bukan Redis)
- Tidak ada UI dashboard bawaan
Cocok kalau: backend punya Postgres, throughput menengah (sesuai skenario), simpel infra

### Opsi C: In-memory + cron (self-built)
Pro:
- Zero dependency — embed di backend process
- Zero cost (Rp 0)
- Simpel untuk MVP
Con:
- Job lost kalau process restart (no persistence)
- Tidak scalable horizontal (kalau spawn 2 backend instance, job duplikat)
- Harus reimplement retry, priority, monitoring dari nol
Cocok kalau: MVP single-instance, job bukan critical (boleh lost), dev-only

### Rekomendasi: Opsi B (PostgreSQL + pg-boss)
Alasan:
- Skenario Anda (500 job/hari, 30-60 dtk latency) jauh di bawah limit pg-boss (1000 job/detik)
- Postgres sudah ada di stack ERP, zero new service = zero cost + zero maintenance
- Transactional consistency berguna untuk ERP (job + invoice insert bisa atomic)

Pilih Opsi A kalau: throughput naik ke >5000 job/detik (kalau business grow 10x), atau butuh UI dashboard professional.
Pilih Opsi C kalau: pure MVP, job boleh lost kalau server crash.
```
