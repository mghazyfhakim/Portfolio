---
name: brainstorm-3-options
description: Brainstorm dengan format 3 opsi + trade-off eksplisit + rekomendasi
version: 1.0.0
author: AI Engineering Team - Z.ai
license: MIT
metadata:
  hermes:
    tags: [Brainstorm, Decision Making, Architecture]
---

# Brainstorm 3 Options — Structured Decision Making

Skill ini bantu user bikin keputusan teknis dengan format terstruktur: 3 opsi + trade-off + rekomendasi. Bukan 5+ opsi yang membingungkan.

## When to Use

Load skill ini saat user:
- Minta "brainstorm" atau "ide" atau "saran"
- Tanya "gimana cara terbaik untuk..."
- Bilang "ada beberapa opsi, bantu pilih"
- Minta architecture decision yang punya trade-off

TIDAK load saat:
- User tanya fakta spesifik ("apa itu async/await?")
- User minta code snippet langsung
- User minta fix bug spesifik

## Quick Reference — Output Format

Setiap brainstorm harus punya struktur:

```
## [Topic]

### Konteks
[1-2 kalimat: apa masalahnya, kenapa perlu brainstorm]

### Opsi A: [nama singkat]
Pro:
- [argumen +1]
Con:
- [argumen -1]
Cocok kalau: [skenario]

### Opsi B: [nama singkat]
Pro/Con/Cocok kalau: ...

### Opsi C: [nama singkat]
Pro/Con/Cocok kalau: ...

### Rekomendasi: [Opsi X]
Alasan: [1-2 kalimat kenapa]
```

## Procedure

1. Pahami konteks dulu — baca pertanyaan user, identifikasi constraint (budget, timeline, team skill, existing system).
2. Generate 3 opsi yang distinct (bukan variasi minor dari 1 opsi). Harus punya trade-off berbeda.
3. Jangan generate opsi "straw man" (opsi yang sengaja dibikin jelek supaya opsi lain menang). Setiap opsi harus viable.
4. Trade-off harus spesifik — bukan "complex" tapi "perlu 2 minggu ekstra dev". Bukan "scalable" tapi "handle 10k RPS tanpa vertical scaling".
5. Kasih rekomendasi — jangan biarkan user pilih sendiri. Anda engineer, punya opinion. Tapi tandai kalau ada assumption yang membuat rekomendasi bisa berubah.

## Common Opsi Archetypes

| Archetype | Pattern |
|---|---|
| Build vs Buy vs Open-source | Bikin sendiri / SaaS / OSS self-hosted |
| Simple vs Performant vs Maintainable | Quick hack / Optimized / Well-architected |
| Short-term vs Long-term vs Balanced | Cepat sekarang / Scalable / Compromise |
| In-house vs Managed vs Hybrid | Self-manage / Cloud / Mix |

Kalau user minta brainstorm tanpa constraint, asumsikan default constraint:
- Budget: frugal (Rp 0 - Rp 1jt/bulan)
- Timeline: 1-3 bulan untuk MVP
- Team: 1-3 developer
- Existing system: greenfield (kalau tidak disebut)

## Pitfalls

- Jangan kasih 5+ opsi — paralyze choice. 3 adalah sweet spot.
- Jangan kasih opsi yang sama dengan nama beda — beda nama tapi trade-off sama = 1 opsi saja.
- Jangan vague: "Pro: lebih baik" TIDAK berguna. Sebutkan: "Pro: handle 10x traffic tanpa rewrite".
- Jangan takut bilang "tidak ada opsi bagus" — kalau semua opsi punya critical flaw, sebutkan, lalu kasih rekomendasi "pilih yang paling tidak buruk untuk skenario X".
- Jangan rekomendasi tanpa alasan — rekomendasi tanpa alasan = useless opinion.
- Jangan ignore user constraint — kalau user bilang "budget Rp 0", jangan rekomendasi SaaS berbayar.

## Verification

Setelah output brainstorm, user harus bisa:
1. Paham 3 opsi dengan jelas (1 menit baca per opsi)
2. Tahu trade-off masing-masing (pro/con konkret)
3. Tahu opsi mana yang cocok untuk skenario dia
4. Punya rekomendasi yang actionable
