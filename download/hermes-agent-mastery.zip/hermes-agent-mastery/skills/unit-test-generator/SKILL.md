---
name: unit-test-generator
description: Generate unit test dari function signature — coverage critical path + edge case, bukan 100% line coverage
version: 1.0.0
author: AI Engineering Team - Z.ai
license: MIT
metadata:
  hermes:
    tags: [Testing, Unit Test, TDD]
    related_skills: [code-review]
---

# Unit Test Generator — Critical Path First

Skill ini generate unit test dari function yang user kasih. Prioritas: critical path + edge case, BUKAN 100% line coverage (yang sering waste).

## When to Use

Load skill ini saat user:
- Minta "buat unit test untuk function ini"
- Share function dan bilang "test ini"
- Tanya "apa yang harus di-test dari function X?"

## Quick Reference — Test Pyramid Priority

| Priority | Apa yang test | Coverage target |
|---|---|---|
| 1 (wajib) | Critical path (happy path + main business logic) | 100% critical path |
| 2 (wajib) | Edge case (null, empty, boundary) | 80%+ edge case |
| 3 (sebaiknya) | Error case (invalid input, exception) | 80%+ error case |
| 4 (optional) | Implementation detail (private method) | Skip kalau bisa |

## Procedure

1. **Baca function signature**: nama, parameter, return type.
2. **Identifikasi critical path**: input normal → output expected.
3. **Identifikasi edge case**: null, undefined, empty array, 0, boundary value.
4. **Identifikasi error case**: invalid input, exception, network failure.
5. **Generate test dengan structure AAA**:
   ```typescript
   describe('functionName', () => {
     it('should [behavior] when [condition]', () => {
       // Arrange
       const input = ...
       // Act
       const result = functionName(input)
       // Assert
       expect(result).toBe(expected)
     })
   })
   ```
6. **Pakai framework yang user pakai** (lihat import atau tanya). Default: jest untuk JS/TS, pytest untuk Python.
7. **Jangan generate test untuk getter/setter atau pure data class** — waste.

## Test Naming Convention

Format: `should [expected behavior] when [condition/state]`

Contoh:
- ✅ `should return 0 when input is 0`
- ✅ `should throw ValidationError when email is invalid`
- ✅ `should return empty array when no items match filter`

❌ Hindari:
- `test1`, `test2`, `test_function` (tidak deskriptif)
- `should work correctly` (vague)
- `should handle edge case` (mana edge case-nya?)

## Common Edge Cases (universal checklist)

| Type | Test case |
|---|---|
| Number | `0`, `-1`, `Number.MAX_SAFE_INTEGER`, `Number.MIN_SAFE_INTEGER`, `NaN`, `Infinity` |
| String | `''` (empty), `' '` (whitespace only), very long string, string with special char |
| Array | `[]` (empty), `[null, null]`, array with 1 element, very large array |
| Object | `{}` (empty), object dengan null fields, deeply nested object |
| Date | Invalid date, timezone edge (UTC vs local), leap year (Feb 29) |
| Null/Undefined | Both `null` and `undefined` (di JS keduanya beda) |

## Pitfalls

- **Jangan mock yang tidak perlu**: kalau function pure (no side effect), test langsung tanpa mock. Mock hanya untuk external dependency (DB, API, fs).
- **Jangan test implementation detail**: test public behavior, bukan private method. Kalau private method kompleks, extract jadi public function terpisah.
- **Jangan over-test**: kalau function sederhana (`function add(a, b) { return a + b }`), cukup 3-4 test case (positive, negative, zero). Tidak perlu 20 test case.
- **Jangan assert implementation**: assert hasil/output, bukan cara function bekerja. Test harus tetap pass kalau internal di-refactor.
- **Jangan generate test untuk trivial code**: getter/setter, constant declaration, type definition — tidak perlu unit test.

## Verification

Setelah generate test:
1. Test harus bisa di-run langsung (`npm test` atau `pytest`)
2. Test harus FAIL kalau function di-break (ubah return value)
3. Test harus PASS untuk function yang benar
4. Critical path 100% ter-cover
5. Edge case 80%+ ter-cover

Kalau user run test dan ada yang fail, kemungkinan:
- Function punya bug (test menemukan masalah — ini BAGUS)
- Test salah assert (fix test, bukan function)
- Mock tidak sesuai (cek mock setup)

## Example Output

User kasih function:
```typescript
function calculateDiscount(price: number, discountPercent: number): number {
  if (discountPercent < 0 || discountPercent > 100) {
    throw new Error('Discount must be between 0 and 100')
  }
  return price - (price * discountPercent / 100)
}
```

Response skill:

```typescript
import { calculateDiscount } from './pricing'

describe('calculateDiscount', () => {
  // === Critical path ===
  it('should return discounted price when valid input', () => {
    // Arrange
    const price = 100
    const discount = 20
    // Act
    const result = calculateDiscount(price, discount)
    // Assert
    expect(result).toBe(80)
  })

  it('should return original price when discount is 0', () => {
    expect(calculateDiscount(100, 0)).toBe(100)
  })

  it('should return 0 when discount is 100%', () => {
    expect(calculateDiscount(100, 100)).toBe(0)
  })

  // === Edge case ===
  it('should handle price 0', () => {
    expect(calculateDiscount(0, 50)).toBe(0)
  })

  it('should handle decimal price', () => {
    expect(calculateDiscount(99.99, 10)).toBe(89.991)
  })

  // === Error case ===
  it('should throw when discount is negative', () => {
    expect(() => calculateDiscount(100, -10)).toThrow('Discount must be between 0 and 100')
  })

  it('should throw when discount exceeds 100', () => {
    expect(() => calculateDiscount(100, 101)).toThrow('Discount must be between 0 and 100')
  })
})
```

Alasan test set:
- 3 critical path: positive case, 0% discount, 100% discount (boundary)
- 2 edge case: price 0, decimal price (test float handling)
- 2 error case: negative discount, >100 discount (test validation)

Skip: tidak test `NaN` input karena function tidak explicit handle (akan throw generic error). Tambah test `NaN` kalau user mau strict.
