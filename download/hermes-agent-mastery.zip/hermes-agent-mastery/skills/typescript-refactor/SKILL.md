---
name: typescript-refactor
description: Refactor TypeScript dari anti-pattern ke idiomatic code (modern ES2024+)
version: 1.0.0
author: AI Engineering Team - Z.ai
license: MIT
metadata:
  hermes:
    tags: [TypeScript, Refactoring, Code Quality]
    related_skills: [code-review]
---

# TypeScript Refactor — Anti-Pattern to Idiomatic

Skill ini refactor kode TypeScript dari pola lama/anti-pattern ke idiomatic modern. Lead dengan diff, jangan paragraf penjelasan.

## When to Use

Load skill ini saat user:
- Minta "refactor kode ini"
- Share kode TypeScript dan bilang "ini bisa dibikin lebih TypeScript-y?"
- Kasih prompt "make this more idiomatic"
- Tanya "ada cara lebih baik untuk nulis ini di TS?"

## Quick Reference — Anti-Pattern Detection

| Anti-Pattern | Idiomatic Replacement |
|---|---|
| `any` type | `unknown` + type narrowing, atau specific type |
| `as unknown as X` cast | Proper type guard atau generic |
| `if (x !== null && x !== undefined)` | `if (x != null)` atau optional chaining |
| Manual `for` loop untuk filter/map | `Array.filter()`, `Array.map()` |
| Nested ternary | `switch` atau extract function |
| `Promise.then().catch()` | `async/await` + `try/catch` |
| `interface Foo extends Bar` (3+ level) | Composition atau type alias |
| `Record<string, any>` | `Map<K, V>` atau `Record<string, unknown>` dengan type guard |
| Mutable class fields | `readonly` + immutable update |
| `enum` (default) | `const` object + `typeof` atau union type |

## Procedure

1. Identifikasi target refactor: user sebut apa yang mau di-refactor, atau tunjuk sendiri 1-3 worst offenders.
2. Baca context sekitar kode yang di-refactor — jangan refactor dalam vacuum.
3. Output dalam format diff:
   ```diff
   - kode lama
   + kode baru
   ```
4. Sebutkan alasan singkat di bawah diff (1-2 kalimat, bukan paragraf).
5. Jangan over-refactor — kalau user minta refactor 1 function, jangan refactor 5 function sekaligus.
6. Jaga backward compatibility: kalau refactor mengubah public API, sebutkan breaking change.

## Common Refactor Patterns

### Pattern 1: any → proper type

```diff
- function processData(data: any) {
-   return data.items.map((i: any) => i.name)
- }
+ function processData<T extends { items: Array<{ name: string }> }>(data: T) {
+   return data.items.map((i) => i.name)
+ }
```

### Pattern 2: Manual loop → functional

```diff
- const names: string[] = []
- for (const user of users) {
-   if (user.active) {
-     names.push(user.name)
-   }
- }
+ const names = users.filter((u) => u.active).map((u) => u.name)
```

### Pattern 3: Null chain → optional chaining

```diff
- const city =
-   user && user.profile && user.profile.address && user.profile.address.city
-     ? user.profile.address.city
-     : 'Unknown'
+ const city = user?.profile?.address?.city ?? 'Unknown'
```

### Pattern 4: enum → union type

```diff
- enum Status {
-   Active = 'ACTIVE',
-   Inactive = 'INACTIVE',
-   Pending = 'PENDING',
- }
+ type Status = 'ACTIVE' | 'INACTIVE' | 'PENDING'
```

### Pattern 5: Promise chain → async/await

```diff
- function fetchUser(id: string) {
-   return api.get(`/users/${id}`)
-     .then((res) => res.json())
-     .then((data) => data.user)
-     .catch((err) => {
-       console.error(err)
-       return null
-     })
- }
+ async function fetchUser(id: string) {
+   try {
+     const res = await api.get(`/users/${id}`)
+     const data = await res.json()
+     return data.user
+   } catch (err) {
+     console.error(err)
+     return null
+   }
+ }
```

## Pitfalls

- Jangan refactor tanpa test: kalau user share kode tanpa test, sebutkan "pastikan ada test dulu sebelum refactor ini, karena behavior harus tetap sama".
- Jangan refactor for refactor's sake: kalau kode udah idiomatic, bilang "sudah bagus, tidak perlu refactor". Jangan cari masalah yang tidak ada.
- Jangan pakai fitur ES terlalu baru tanpa cek target: `structuredClone` (ES2022) — pastikan target environment support.
- Jangan ubah public API tanpa konfirmasi: kalau function ini dipakai di tempat lain, sebutkan "ini breaking change, perlu update caller di file X dan Y".

## Verification

Setelah refactor, user harus bisa:
1. Copy diff langsung ke file, tanpa manual edit
2. Kode compile tanpa TypeScript error
3. Test (kalau ada) tetap pass
4. Paham alasan setiap perubahan (singkat, jelas)
